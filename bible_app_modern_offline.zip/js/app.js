/*
 Modern per-chapter offline Bible reader (KJV)
 - Expects per-chapter JSON files in ./books/<Book>/<Chapter>.json
 - Each chapter JSON is an object mapping verseNumber -> verseText
 - Includes dark-mode toggle, search over cached books, and next/prev navigation
*/
const OT = ["Genesis","Exodus","Leviticus","Numbers","Deuteronomy","Joshua","Judges","Ruth","1Samuel","2Samuel","1Kings","2Kings","1Chronicles","2Chronicles","Ezra","Nehemiah","Esther","Job","Psalms","Proverbs","Ecclesiastes","SongofSolomon","Isaiah","Jeremiah","Lamentations","Ezekiel","Daniel","Hosea","Joel","Amos","Obadiah","Jonah","Micah","Nahum","Habakkuk","Zephaniah","Haggai","Zechariah","Malachi"];
const NT = ["Matthew","Mark","Luke","John","Acts","Romans","1Corinthians","2Corinthians","Galatians","Ephesians","Philippians","Colossians","1Thessalonians","2Thessalonians","1Timothy","2Timothy","Titus","Philemon","Hebrews","James","1Peter","2Peter","1John","2John","3John","Jude","Revelation"];

const booksGrid = document.getElementById('booksGrid');
const booksArea = document.getElementById('booksArea');
const chapterArea = document.getElementById('chapterArea');
const bookTitle = document.getElementById('bookTitle');
const chapterSelect = document.getElementById('chapterSelect');
const reader = document.getElementById('reader');
const chapterInfo = document.getElementById('chapterInfo');
const resultsArea = document.getElementById('searchResults');
const resultsDiv = document.getElementById('results');
let currentBook = '';
let currentChapter = 1;
let cache = {}; // cache per-book (book->chap->verses)

document.getElementById('showOT').addEventListener('click', ()=>renderBooks(OT));
document.getElementById('showNT').addEventListener('click', ()=>renderBooks(NT));
document.getElementById('openChapter').addEventListener('click', ()=>openChapter(currentBook, Number(chapterSelect.value)));
document.getElementById('prevChap').addEventListener('click', ()=>navigateChapter(-1));
document.getElementById('nextChap').addEventListener('click', ()=>navigateChapter(1));
document.getElementById('searchBtn').addEventListener('click', ()=>doSearch(document.getElementById('searchBox').value));

document.getElementById('darkToggle').addEventListener('change', (e)=>{
  const app = document.getElementById('app');
  app.setAttribute('data-theme', e.target.checked ? 'dark' : 'light');
});

function renderBooks(list){
  booksGrid.innerHTML='';
  chapterArea.style.display='none';
  resultsArea.style.display='none';
  list.forEach(bk=>{
    const d = document.createElement('div');
    d.className='book-card';
    d.textContent = bk.replace(/([0-9])/g,' $1'); // separate numbers
    d.addEventListener('click', ()=>selectBook(bk));
    booksGrid.appendChild(d);
  });
}

async function selectBook(book){
  currentBook = book;
  bookTitle.textContent = book;
  booksArea.style.display='none';
  chapterArea.style.display='block';
  resultsArea.style.display='none';
  chapterSelect.innerHTML = '<option>Loading...</option>';
  // attempt to discover how many chapters by trying to fetch increasing chapter numbers until fail (but limit to 200)
  const chapters = await discoverChapters(book);
  chapterSelect.innerHTML = '';
  for(let i=1;i<=chapters;i++){
    const o = document.createElement('option'); o.value=i; o.textContent='Chapter '+i; chapterSelect.appendChild(o);
  }
  chapterInfo.textContent = chapters + ' chapters';
  // pre-cache chapter 1
  await loadChapterJson(book,1);
  openChapter(book,1);
}

async function discoverChapters(book){
  // quick approach: try known max chapters (Psalms 150, others less). We'll probe incrementally until we fail 3 times.
  const probeMax = 200;
  let maxFound = 0;
  for(let i=1;i<=probeMax;i++){
    try{
      const r = await fetch(`books/${encodeURIComponent(book)}/${i}.json`);
      if(!r.ok) {
        if(i>50) break;
        else continue;
      }
      maxFound = i;
    } catch(e){
      break;
    }
    // small optimization: stop if we've passed a likely max (e.g., >150 for Psalms)
    if(i>150) break;
  }
  return maxFound || 1;
}

async function loadChapterJson(book, chapter){
  cache[book] = cache[book] || {};
  if(cache[book][chapter]) return cache[book][chapter];
  try{
    const r = await fetch(`books/${encodeURIComponent(book)}/${chapter}.json`);
    if(!r.ok) throw new Error('Not found');
    const data = await r.json();
    cache[book][chapter] = data;
    return data;
  } catch(e){
    // no local file
    return null;
  }
}

async function openChapter(book, chapter){
  currentBook = book; currentChapter = chapter;
  const data = await loadChapterJson(book, chapter);
  reader.innerHTML = '';
  if(!data){
    reader.innerHTML = '<div class="small">Chapter not available offline. Use the build script to download per-chapter JSON files.</div>';
    return;
  }
  const keys = Object.keys(data).sort((a,b)=>Number(a)-Number(b));
  keys.forEach(v=>{
    const div = document.createElement('div'); div.className='verse';
    div.innerHTML = `<span class="verse-number">${v}</span> <span class="verse-text">${escapeHtml(data[v])}</span>`;
    reader.appendChild(div);
  });
  // set select to current chapter
  chapterSelect.value = chapter;
  // scroll to top
  reader.scrollTop = 0;
}

function navigateChapter(delta){
  const newChap = Number(currentChapter) + delta;
  if(newChap<1) return;
  openChapter(currentBook, newChap);
}

function escapeHtml(s){ return s ? s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;') : ''; }

async function doSearch(q){
  q = (q||'').trim();
  if(!q) return alert('Enter search term');
  // search over cached chapters only
  const results = [];
  for(const bk of Object.keys(cache)){
    const bookData = cache[bk];
    for(const ch of Object.keys(bookData)){
      const chap = bookData[ch];
      for(const v of Object.keys(chap)){
        const text = chap[v];
        if(text && text.toLowerCase().includes(q.toLowerCase())){
          results.push({bk,ch,v,text});
          if(results.length>500) break;
        }
      }
      if(results.length>500) break;
    }
    if(results.length>500) break;
  }
  if(results.length===0){
    alert('No results in cached chapters. Open books to cache them locally first.');
    return;
  }
  resultsArea.style.display='block';
  resultsDiv = document.getElementById('results');
  resultsDiv.innerHTML = '';
  results.forEach(r=>{
    const el = document.createElement('div');
    el.innerHTML = `<div><strong>${r.bk} ${r.ch}:${r.v}</strong></div><div>${escapeHtml(r.text)}</div><hr/>`;
    resultsDiv.appendChild(el);
  });
}
