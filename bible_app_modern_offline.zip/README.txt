Bible Reader — Offline Package (Modern UI)
=========================================

What is included:
- index.html        -> Modern reader UI with dark mode toggle
- style.css         -> Styling for light & dark themes
- js/app.js         -> App logic; loads per-chapter JSON from books/<Book>/<Chapter>.json
- samples/Genesis/1.json and 2.json -> sample per-chapter JSON files (small)
- samples/Matthew/1.json and 2.json -> sample per-chapter JSON files (small)
- download_and_split.sh -> Bash script that downloads per-book JSON from aruljohn/Bible-kjv and splits them into per-chapter JSONs using jq

How to get a fully offline package (per-chapter JSONs):
1. On a machine with curl and jq installed (Linux/macOS or Windows with Git Bash), run:
   bash download_and_split.sh
   This will create the ./books/<Book>/<Chapter>.json files using the public GitHub repo aruljohn/Bible-kjv as the source.

2. Alternatively, if you already have per-book JSONs, place them under books/<Book>/ and ensure each chapter is saved as <n>.json containing an object mapping verse->text.

How to test locally:
- Open index.html in a browser (it will try to load chapters under books/; sample chapters are included under samples/)
- To test the included sample chapters, copy the samples folder into books (e.g. mv samples Genesis && mkdir -p books && mv samples books/ )
  or just create a books folder and copy sample files into books/Genesis/1.json etc.

Using in AppCreator24:
- You can host the folder on GitHub Pages or Netlify and set AppCreator24 WebView to the hosted index.html
- Or, paste index.html + style + js into an HTML section and upload books folder to a static host and update paths accordingly

Notes:
- Source for KJV per-book JSON: https://github.com/aruljohn/Bible-kjv (public-domain KJV text in JSON per book)
- The included download script uses that repo's raw files to create per-chapter JSONs.

