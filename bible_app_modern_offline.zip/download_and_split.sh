#!/bin/bash
# download_and_split.sh
# Downloads per-book JSON files from aruljohn/Bible-kjv and splits into per-chapter JSON files under ./books/<Book>/<Chapter>.json
# Requirements: curl, jq, mkdir, unzip
set -e
BASE=https://raw.githubusercontent.com/aruljohn/Bible-kjv/master
OUTDIR=books
mkdir -p "$OUTDIR"
books=(Genesis Exodus Leviticus Numbers Deuteronomy Joshua Judges Ruth 1Samuel 2Samuel 1Kings 2Kings 1Chronicles 2Chronicles Ezra Nehemiah Esther Job Psalms Proverbs Ecclesiastes SongofSolomon Isaiah Jeremiah Lamentations Ezekiel Daniel Hosea Joel Amos Obadiah Jonah Micah Nahum Habakkuk Zephaniah Haggai Zechariah Malachi Matthew Mark Luke John Acts Romans 1Corinthians 2Corinthians Galatians Ephesians Philippians Colossians 1Thessalonians 2Thessalonians 1Timothy 2Timothy Titus Philemon Hebrews James 1Peter 2Peter 1John 2John 3John Jude Revelation)

for b in "${books[@]}"; do
  echo "Processing $b ..."
  mkdir -p "$OUTDIR/$b"
  url="$BASE/$b.json"
  tmpfile="$(mktemp)"
  if curl -sSfL "$url" -o "$tmpfile"; then
    # the book JSON is expected as top-level object: { "1": {"1":"...","2":"..."}, "2": {...} }
    # iterate chapters and write each chapter into separate file
    chapters=$(jq -r 'keys[]' "$tmpfile" | sort -n)
    for ch in $chapters; do
      jq -r --arg ch "$ch" '.[$ch]' "$tmpfile" > "$OUTDIR/$b/$ch.json"
    done
    echo "Done $b"
  else
    echo "Failed to download $url"
  fi
  rm -f "$tmpfile"
done
echo "All done. Per-chapter JSON files are in the books/ folder."
